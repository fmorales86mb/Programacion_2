using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades{

    //  Mostrar agregará los datos propios.
    //ii.La propiedad PrecioFinal retornará el precio aplicando un aumento del 10% para tipo de
    //servicio SemiCama y 20% para Ejecutivo.
    [Serializable]
    public class PasajeMicro : Pasaje
{
  public Servicio tipoServicio;
    public PasajeMicro()
    {

    }
    public PasajeMicro(string origen, string destinto, Pasajero pasajero, float precio, DateTime fecha, Servicio tipoServicio) : base(
      origen, destinto, pasajero, precio, fecha)
    {
      this.tipoServicio = tipoServicio;

    }

  public override float PrecioFinal
    {
      get
      {
        float auxPrecio = base.Precio;
        if (this.tipoServicio == Servicio.SemiCama)
        {
          return (auxPrecio * (float)1.1);
        }
        else if (this.tipoServicio == Servicio.Ejecutivo)
        {
          return (auxPrecio * (float)1.2);
        }

        return auxPrecio;
      }

    }
    public override string Mostrar()
    {
      StringBuilder sb = new StringBuilder();
      sb.AppendLine(base.Mostrar());
      sb.AppendLine("Tipo De Servicio" + this.tipoServicio);
      sb.AppendLine("Precio Final" + this.PrecioFinal);
   
      return sb.ToString();
    }
  }
}
