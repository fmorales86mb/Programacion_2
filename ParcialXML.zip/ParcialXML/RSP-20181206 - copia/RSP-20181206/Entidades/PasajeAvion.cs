using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    //  i.Mostrar agregará los datos propios.
    //ii.La propiedad PrecioFinal retornará el precio aplicando un descuento del 10% para viajes con
    //una escala, 20% con dos escalas y 30% con más de 2 eescalas
    [Serializable]
    public class PasajeAvion : Pasaje
    {
        public int cantidadEscalas;


        public PasajeAvion()
        {

        }

        public PasajeAvion(string origen, string destinto, Pasajero pasajero, float precio, DateTime fecha, int CantidadEscalas) : base(
          origen, destinto, pasajero, precio, fecha)
        {
            this.cantidadEscalas = CantidadEscalas;
        }
        public override float PrecioFinal
        {
            get
            {
                float precioAux = base.Precio;
                if (this.cantidadEscalas > 0)
                {
                    if (this.cantidadEscalas == 1)
                    {
                        return (precioAux * (float)0.9);
                    }
                    else if (this.cantidadEscalas == 2)
                    {
                        return (precioAux * (float)0.8);
                    }
                    else
                    {
                        return (precioAux * (float)0.7);
                    }
                }
                return precioAux;
            }
        }
        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendLine("CantidadEscalas" + this.cantidadEscalas);
            sb.AppendLine("Pecio Final contando escalas" + this.PrecioFinal);
            return sb.ToString();
        }

    }
}
