using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void DelegadoMensaje(string mensaje);

    [Serializable]
    public class Agencia
    {
        private string nombre;
        private List<Pasaje> pasajesVendidos;

        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                this.nombre = value;
            }
        }

        public List<Pasaje> PasajesVendidos
        {
            get
            {
                return this.pasajesVendidos;
            }
            set
            {
                this.pasajesVendidos = value;
            }
        }


        public event DelegadoMensaje informar;
        public Agencia()
        {
            this.pasajesVendidos = new List<Pasaje>();
        }

        public Agencia(string nombre) : this()
        {
            this.nombre = nombre;
        }

        public static bool operator ==(Agencia a, Pasaje p)
        {
            foreach (Pasaje pas in a.pasajesVendidos)
            {
                if (pas == p)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Agencia a, Pasaje p)
        {
            return !(a == p);
        }

        public static Agencia operator +(Agencia a, Pasaje p)
        {

            if (a != p)
            {
                a.pasajesVendidos.Add(p);
                a.informar("Pasaje emitido Correctamente");
                return a;
            }
            else
            {
                a.informar("El pasaje ya fue emitido con anterioridad");
                return a;
            }
        }

        public float CalcularGanancia()
        {
            float auxTotal = 0;
            foreach (Pasaje pas in this.pasajesVendidos)
            {
                auxTotal += pas.PrecioFinal;
            }
            return auxTotal;
        }

        public static explicit operator string(Agencia a)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Agencia: " + a.nombre);
            sb.AppendLine("Pasajes vendidos:");
            foreach (Pasaje p in a.pasajesVendidos)
            {
                sb.AppendLine(p.Mostrar());
            }
            sb.AppendLine("Ganancia: " + a.CalcularGanancia());

            return sb.ToString();
        }
    }
}
