using Entidades;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VistaForm
{
    public partial class FormLogin : Form
    {
        Usuario usuario;
        public FormLogin()
        {
            InitializeComponent();
            txtClave.UseSystemPasswordChar = true;
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            //ALUMNO
          
    string StrConection;
    SqlConnection Con;
      StrConection = @"Data Source=.\SQLEXPRESS;Initial Catalog=final-20180802;Integrated Security=True";
      Con = new SqlConnection(StrConection);

      try
      {
       
        SqlCommand comando;

        comando = new SqlCommand();
        comando.CommandType = System.Data.CommandType.Text;

        comando.Connection = Con;

        comando.CommandText = "SELECT nombre, clave FROM Usuarios WHERE nombre='" + txtUsuario.Text + "' AND clave='" + txtClave.Text + "'";
        Con.Open();

        SqlDataReader oDr = comando.ExecuteReader();

                if (oDr.Read())
                {
                    MessageBox.Show("Login exitoso.");
                    FormAgencia frm = new FormAgencia();
                    frm.Show();
                }
                else
                {
                    MessageBox.Show("Datos incorrectos.");
                }

            }
      catch (Exception ex)
      {
        usuario = null;
        throw ex;
      }
      finally
      {
        Con.Close();
      }

      if (usuario != null)
            {
                this.Hide();
                FormAgencia f2 = new FormAgencia();
                f2.ShowDialog();
            }

        }

        private void btnRegistrarse_Click(object sender, EventArgs e)
        {
      bool errorDigitos = false;
      string StrConection;
      SqlConnection Con;
      StrConection = @"Data Source=.\SQLEXPRESS;Initial Catalog=final-20180802;Integrated Security=True";
      Con = new SqlConnection(StrConection);
      //ALUMNO
      string auxClave = txtClave.Text;
      if (auxClave.Length < 8)
      {
        errorDigitos = true;
      }
  
      string query = string.Format("insert into dbo.Usuarios values('{0}', '{1}')",
                txtUsuario.Text, txtClave.Text);

      SqlCommand command = new SqlCommand(query, Con);

      try
      {
        if (errorDigitos)
        {
          MessageBox.Show("la clave debe tener almenos 8 digito", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
          throw new Exception();
        }
        Con.Open();
        if (command.ExecuteNonQuery() > 0)
          MessageBox.Show("Usuario Registrado!");
      }
      catch(Exception)
      {
        MessageBox.Show("Error al cargar usuario", "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
      }
      finally
      {
        if (Con.State != System.Data.ConnectionState.Closed)
          Con.Close();
      }

      //limpio los controles después del registro
      this.txtUsuario.Clear();
            this.txtClave.Clear();
            usuario = null;

        }

  }
}
