using System.Windows.Forms;
using Entidades;
using System;
using Archivos;

namespace VistaForm
{
    public partial class FormAgencia : Form
    {
        private Agencia agencia;
        
   

    public FormAgencia()
        {
            InitializeComponent();
            agencia = new Agencia("Agencia UTN");
            string[] items = new string[] { "Micro", "Avión" };
            this.cmbTipoPasaje.DataSource = items;
            this.cmbTipoPasaje.SelectedIndex = 0;
            this.nudEscalas.Enabled = false;


            this.txtNombre.Text = "Nombre";
            this.txtApellido.Text = "Apellido";
            this.txtDni.Text = "33444555";
            this.txtOrigen.Text = "Buenos Aires";
            this.txtDestino.Text = "Cordoba";
            cmbTipoServicio.DataSource = Servicio.GetValues(typeof(Servicio));
        }
        public void MostrarMensaje(string msj)
        {
            MessageBox.Show(msj);
        }
        private void btnEmitirPasaje_Click(object sender, System.EventArgs e)
        {
            //try
            //{
                if (cmbTipoPasaje.Text == "Avión")
                {
                    Pasajero psj = new Pasajero(txtNombre.Text, txtApellido.Text, txtDni.Text);
                    float auxF = float.Parse(txtPrecio.Text);
                    System.DateTime dt = System.DateTime.Parse(dtpFechaPartida.Text);
                    PasajeAvion pasAv = new PasajeAvion(txtOrigen.Text, txtDestino.Text, psj, auxF, dt, (int)nudEscalas.Value);
                    agencia += pasAv;
                }
                if (cmbTipoPasaje.Text == "Micro")
                {
                    Pasajero psj = new Pasajero(txtNombre.Text, txtApellido.Text, txtDni.Text);
                    float auxF = float.Parse(txtPrecio.Text);
                    System.DateTime dt = System.DateTime.Parse(dtpFechaPartida.Text);
                    Servicio srv = new Servicio();
                    if (cmbTipoServicio.Text == "Comun") srv = Servicio.Comun;
                    if (cmbTipoServicio.Text == "SemiCama") srv = Servicio.SemiCama;
                    if (cmbTipoServicio.Text == "Ejecutivo") srv = Servicio.Ejecutivo;
                    PasajeMicro pasMic = new PasajeMicro(txtOrigen.Text, txtDestino.Text, psj, auxF, dt, srv);
                    agencia += pasMic;
                }
           //}
            //catch (Exception)
            //{
            //    MessageBox.Show("Error agregando a agencia");
            //}

 
  
        }

        private void btnMostrar_Click(object sender, System.EventArgs e)
        {
      rtbMostrar.Text = (string)agencia;
        }

        private void btnGuardar_Click(object sender, System.EventArgs e)
        {
      try
      {
        XML<Agencia> serializador = new XML<Agencia>();
        serializador.Guardar("Agencia.xml", agencia);
     }
            catch (Exception ex)
            {
                MessageBox.Show("Error al serializar" + ex.Message);
            }

        }

        private void cmbTipoPasaje_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            if (this.cmbTipoPasaje.SelectedIndex == 0)
            {
                this.nudEscalas.Enabled = false;
                this.nudEscalas.Value = 0;
                this.cmbTipoServicio.Enabled = true;
            }
            else
            {
                this.nudEscalas.Enabled = true;
                this.cmbTipoServicio.Enabled = false;
            }
        }

        private void FormAgencia_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

    private void FormAgencia_Load(object sender, EventArgs e)
    {
            agencia.informar += MostrarMensaje;
    }
  }
}
