using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Archivos
{
    public class XML<T> : IArchivo<T>
    {
        public void Guardar(string destino, T dato)
        {
            // se tiene que inicializar en null.
            XmlTextWriter writer = null;
            XmlSerializer serializer;

            try
            {
                writer = new XmlTextWriter(destino, Encoding.Default);
                serializer = new XmlSerializer(typeof(T));
                serializer.Serialize(writer, dato);
                //writer.Close();    
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                // ac� ir�a el Close
                if (writer.WriteState != WriteState.Closed)
                    writer.Close();
            }
        }

        public T Leer(string origen)
        {
            XmlTextReader reader;
            XmlSerializer serializer;
            T datos;
            try
            {
                reader = new XmlTextReader(origen);
                serializer = new XmlSerializer(typeof(T));
                datos = (T)serializer.Deserialize(reader);
                reader.Close();
                return datos;
            }
            catch (Exception e)
            {
                datos = default(T);
                throw e;
            }
        }
    }
}
