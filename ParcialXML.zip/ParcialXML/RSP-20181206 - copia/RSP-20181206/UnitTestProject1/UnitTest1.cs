using System;
using Archivos;
using Entidades;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    public void TestMethod1()
    {
      Agencia a = new Agencia("agenciaUno");
      Agencia a2 = new Agencia("agenciaUno");
      Pasajero ps = new Pasajero("marcos", "ruben", "45645646");
      DateTime dt = DateTime.Now;
      PasajeAvion pas = new PasajeAvion("canada","chile",ps,1578,dt,1);
      a += pas;
      XML<Agencia> serializador = new XML<Agencia>();
      serializador.Guardar("Agencia.xml", a);
      a2 = serializador.Leer("Agencia.xml");
            foreach (Pasaje p in a.PasajesVendidos)
            {
                foreach (Pasaje p2 in a2.pasajesVendidos)
                {
                    Assert.IsTrue(p == p2);
                }
            }
    

    }
  }
}
